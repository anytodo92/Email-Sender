# Email Sender

This project is admin panel to manage the email sending and history.
