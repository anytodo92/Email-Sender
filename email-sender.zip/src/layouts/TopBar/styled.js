import styled from "styled-components"

export const TopBarWrapper = styled.div`
`