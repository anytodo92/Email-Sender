import styled from "styled-components";

export const HistoryWrapper = styled.div`
`