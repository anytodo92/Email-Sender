export const Message = {
  SUCCEED_SAVE_DATA: 'The data is saved correctly.',
  SUCCEED_DELETE_DATA: 'The data is deleted correclty.',
  SERVER_ERROR: 'The error is happened from the server.',
}

export const PerPageCountList = [5, 10, 25]