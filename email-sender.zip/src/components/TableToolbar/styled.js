import styled from "styled-components"

export const MoreOptionWrapper = styled.div`
  background-color: white;
  border-radius: 5px;
  width: 150px;
`